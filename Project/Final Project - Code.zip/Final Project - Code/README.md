To run this project, import the Festival_Project.gaml model file into GAMA and press the green buttom FestivalModel to run the experiment.
The tab "chart" displays the chart of the acceptance and rejection rate of all agents.
The tab "festival" shows the simulation.